﻿
Imports System.IO
Imports System.Drawing.Drawing2D

Public Class BillingForm
    Private txtto As TextBox
    Dim discount As Decimal
    Private Sub BillingForm_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        Me.KeyPreview = True

        txtto = New TextBox With {
            .Font = New Font("Segoe UI", 12),
            .Location = New Point(60, 405),
            .Size = New Size(240, 95),
            .ForeColor = Color.Black,
            .Multiline = True,
            .BackColor = Color.White,
            .WordWrap = False,
            .BorderStyle = BorderStyle.Fixed3D
}
        Me.Controls.Add(txtto)

        Dim add_free As New CheckBox()
        add_free.Font = New Font("Segoe UI", 10, FontStyle.Regular)
        add_free.AutoSize = True
        add_free.Text = "Add Free Column"
        add_free.Location = New Point(310, 405)
        Me.Controls.Add(add_free)

        Dim add_hsn As New CheckBox()
        add_hsn.Font = New Font("Segoe UI", 10, FontStyle.Regular)
        add_hsn.AutoSize = True
        add_hsn.Text = "Add HSN Column"
        add_hsn.Location = New Point(310, 425)
        Me.Controls.Add(add_hsn)

        Dim mrp As New CheckBox()
        mrp.Font = New Font("Segoe UI", 10, FontStyle.Regular)
        mrp.AutoSize = True
        mrp.Text = "Old MRP/New MRP"
        mrp.Location = New Point(310, 445)
        Me.Controls.Add(mrp)

        Dim disc As New CheckBox()
        disc.Font = New Font("Segoe UI", 10, FontStyle.Regular)
        disc.AutoSize = True
        disc.Text = "Add discount Column"
        disc.Location = New Point(310, 465)
        Me.Controls.Add(disc)

        Dim tocstm As New Label With {
           .Font = New Font("Times New Roman", 18, FontStyle.Bold),
           .Location = New Point(23, 402),
           .Size = New Size(150, 90),
           .ForeColor = Color.Black,
           .Text = "To"}
        Me.Controls.Add(tocstm)
       
        Me.Text = "Apex Pharmacy Billing"
        Me.BackColor = Color.WhiteSmoke
        Me.FormBorderStyle = FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Size = New Size(915, 650)

        SetupUI()
    End Sub

   
    Private Sub AddHoverEffect(ByVal btn As Button)
        AddHandler btn.MouseEnter, Sub()
                                       btn.BackColor = Color.FromArgb(0, 150, 255)
                                   End Sub

        AddHandler btn.MouseLeave, Sub()
                                       btn.BackColor = Color.FromArgb(0, 120, 215)
                                   End Sub
    End Sub

    '======================== UI SETUP ===========================
    Private Sub SetupUI()
        Dim header As New Label With {
            .Text = "Apex Pharmacy Billing Software",
            .Font = New Font("Segoe UI", 20, FontStyle.Bold),
            .AutoSize = False,
            .Height = 60,
            .Dock = DockStyle.Top,
            .TextAlign = ContentAlignment.MiddleCenter,
            .BackColor = Color.FromArgb(60, 120, 216),
            .ForeColor = Color.White
        }
        Me.Controls.Add(header)
        Dim lblQty As New Label With {.Text = "Quantity", .Font = New Font("Segoe UI", 12), .Location = New Point(30, 80)}
        Dim lblItem As New Label With {.Text = "Item Name", .Font = New Font("Segoe UI", 12), .Location = New Point(140, 80)}

        Dim lblPrice As New Label With {.Text = "Price", .Font = New Font("Segoe UI", 12), .Location = New Point(500, 80)}
        txtQty = New TextBox With {.Font = New Font("Segoe UI", 12), .Location = New Point(30, 110), .Width = 100}
        txtItem = New TextBox With {.Font = New Font("Segoe UI", 12), .Location = New Point(140, 110), .Width = 230}

        txtPrice = New TextBox With {.Font = New Font("Segoe UI", 12), .Location = New Point(500, 110), .Width = 150}



        '======================== GRID ===========================
        grid = New DataGridView With {
            .Location = New Point(30, 70),
            .Size = New Size(850, 320),
            .Font = New Font("Segoe UI", 11),
            .AllowUserToAddRows = False,
            .RowHeadersVisible = False,
            .BackgroundColor = Color.White,
            .ScrollBars = ScrollBars.None
        }
        AddHandler grid.CellEndEdit, AddressOf grid_CellEndEdit
        grid.RowTemplate.Height = 32
        grid.ColumnHeadersHeight = 30
        grid.Columns.Add("Qty", "Quantity")
        grid.Columns("Qty").Width = 80
        grid.Columns.Add("Fr", "Free")
        grid.Columns("fr").Width = 50
        grid.Columns.Add("Product", "Product")
        grid.Columns("Product").Width = 157
        grid.Columns.Add("Batch", "Batch")
        grid.Columns.Add("HSN", "HSN")
        grid.Columns.Add("Exp", "Expiry")
        grid.Columns("Exp").Width = 70
        grid.Columns.Add("MRP", "MRP")
        grid.Columns("MRP").Width = 85
        grid.Columns.Add("Rate", "Rate")
        grid.Columns("Rate").Width = 85
        grid.Columns.Add("CGST", "CGST")
        grid.Columns("CGST").Width = 50
        grid.Columns.Add("SGST", "SGST")
        grid.Columns("SGST").Width = 50
        grid.Columns.Add("Amount", "Amount")
        grid.Columns("Amount").Width = 120
        grid.Columns("Amount").ReadOnly = True
        grid.AllowUserToAddRows = True
        grid.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        grid.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        grid.ReadOnly = False
        grid.SelectionMode = DataGridViewSelectionMode.CellSelect

        Me.Controls.Add(grid)

        lblSubtotal = New Label With {.Text = "Subtotal: 0", .Font = New Font("Segoe UI", 13), .Location = New Point(30, 500)}
        lblGST = New Label With {.Text = "GST (18%): 0", .Font = New Font("Segoe UI", 13), .Location = New Point(30, 530)}
        lblTotal = New Label With {.Text = "Total: 0", .Font = New Font("Segoe UI", 16, FontStyle.Bold), .Location = New Point(30, 565)}

        Dim btnSave As New Button With {
            .Text = "Save Bill",
            .Font = New Font("Segoe UI", 12),
            .Location = New Point(680, 500),
            .Size = New Size(150, 40),
            .BackColor = Color.SteelBlue,
            .ForeColor = Color.White
        }
        AddHandler btnSave.Click, AddressOf SaveBill

        Dim btnClear As New Button With {
            .Text = "Clear All",
            .Font = New Font("Segoe UI", 12),
            .Location = New Point(680, 560),
            .Size = New Size(150, 40),
            .BackColor = Color.IndianRed,
            .ForeColor = Color.White
        }
        AddHandler btnClear.Click, AddressOf ClearAll

        Me.Controls.Add(btnSave)
        Me.Controls.Add(btnClear)

    End Sub


    '======================== EVENTS ===========================
    Private Sub AddItem(ByVal sender As Object, ByVal e As EventArgs)

        If txtItem.Text = "" Or txtQty.Text = "" Or txtPrice.Text = "" Then
            MsgBox("Please enter item, quantity and price")
            Exit Sub
        End If

        Dim qty As Decimal = Val(txtQty.Text)
        Dim price As Decimal = Val(txtPrice.Text)
        Dim total As Decimal = qty * price

        grid.Rows.Add(txtItem.Text, qty, price, total)

        txtItem.Clear()
        txtQty.Clear()
        txtPrice.Clear()

        CalculateTotal()
    End Sub

    Private Sub CalculateTotal()
        Dim subtotal As Decimal = 0
        For Each row As DataGridViewRow In grid.Rows
            subtotal += Val(row.Cells("Amount").Value)
        Next

        Dim gst As Decimal = subtotal * 0.18D
        Dim total As Decimal = subtotal + gst

        lblSubtotal.Text = "Subtotal: " & subtotal
        lblGST.Text = "GST (18%): " & gst
        lblTotal.Text = "Total: " & total
    End Sub
    Private Sub SaveBill(ByVal sender As Object, ByVal e As EventArgs)
        Dim sbtotal As Decimal
        Dim grndtotal As Decimal
        For Each row As DataGridViewRow In grid.Rows
            If row.IsNewRow Then Continue For

            Dim qty As Decimal = Val(row.Cells("Qty").Value)
            Dim amt As Decimal = Val(row.Cells("Amount").Value)
            Dim rate As Decimal = Val(row.Cells("Rate").Value)
            Dim cgst As Decimal = Val(row.Cells("CGST").Value)
            Dim sgst As Decimal = Val(row.Cells("SGST").Value)

            sbtotal += qty * rate
            grndtotal += amt
        Next

        Try
            Dim taxableTotal As Decimal = 0
            Dim totalCgst As Decimal = 0
            Dim totalSgst As Decimal = 0
            Dim finalAmount As Decimal = 0

            '---- REMOVE GRID BORDERS ----
            Dim oldCellBorder As DataGridViewCellBorderStyle = grid.CellBorderStyle
            Dim oldGridColor As Color = grid.GridColor

            grid.CellBorderStyle = DataGridViewCellBorderStyle.None
            grid.GridColor = Color.White
            grid.Refresh()
            ' ---- DESELECT GRID BEFORE CAPTURE ----
            grid.ClearSelection()
            grid.CurrentCell = Nothing
            grid.EndEdit()
            grid.Refresh()


            '---- 1. Capture the DataGridView as image ----
            Dim gridImg As New Bitmap(grid.Width, grid.Height)
            grid.DrawToBitmap(gridImg, New Rectangle(0, 0, grid.Width, grid.Height))
            Dim gstSummary = CalculateGstSummary()
            Dim summaryHeight As Integer = 25 + (gstSummary.Count * 22)
            '---- 2. Prepare final bill image ----
            Dim billWidth As Integer = grid.Width + 40
            Dim billHeight As Integer = 180 + grid.Height + summaryHeight + 50

            Dim billImg As New Bitmap(billWidth, billHeight)
            Dim g As Graphics = Graphics.FromImage(billImg)
            g.Clear(Color.White)
            ' After creating Graphics g:
            g.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
            g.InterpolationMode = Drawing2D.InterpolationMode.HighQualityBicubic
            g.PixelOffsetMode = Drawing2D.PixelOffsetMode.HighQuality
            g.CompositingQuality = Drawing2D.CompositingQuality.HighQuality
            g.TextRenderingHint = Drawing.Text.TextRenderingHint.ClearTypeGridFit


            '---- 3. Header ----
            Dim titleFont As New Font("Segoe UI", 22, FontStyle.Bold)
            g.DrawString("Rupa Enterprise", titleFont, Brushes.Black, 19, 20)
            '-----Adress-------'
            Dim addr As New Font("Segoe UI", 12)
            g.DrawString("Checkpost,Memari,Burdwan", addr, Brushes.Black, 21, 60)
            '-----Pin-------'
            Dim pin As New Font("Segoe UI", 12)
            g.DrawString("Pin-713146", pin, Brushes.Black, 21, 82)
            g.DrawString("DL-12563 SW/ 12564 SBW", pin, Brushes.Black, 21, 101)
            '---- 4. Date ----
            Dim f12 As New Font("Segoe UI", 12)
            g.DrawString("Date: " & Now.ToString("dd-MM-yyyy hh:mm tt"), f12, Brushes.Black, 21, 121)

            '---- 5. Customer Address ----
            Dim smallFont As New Font("Segoe UI", 12)

            ' Left position
            Dim billToX As Integer = 530
            Dim billToY As Integer = 24

            ' Split textbox lines
            Dim lines() As String = txtto.Text.Split({Environment.NewLine}, StringSplitOptions.None)

            ' ---- Draw first line using midFont ----
            If lines.Length > 0 Then
                g.DrawString(lines(0), titleFont, Brushes.Black, billToX, billToY)
            End If

            ' ---- Draw rest of the lines using smallFont ----
            Dim currentY As Integer = billToY + 36   ' spacing after first line

            For i As Integer = 1 To lines.Length - 1
                g.DrawString(lines(i), smallFont, Brushes.Black, billToX + 2, currentY)
                currentY += 21   ' spacing for small font lines
            Next

            '---- 6. Draw the grid (with CGST & SGST inside) ----
            g.DrawImage(gridImg, 20, 147)
            ' ---- GST SUMMARY BELOW GRID ----

            Dim startX As Integer = 30
            Dim startY As Integer = 155 + gridImg.Height

            Dim headerFont As New Font("Segoe UI", 11, FontStyle.Bold)
            Dim normalFont As New Font("Segoe UI", 11)
            Dim midfont As New Font("Segoe UI", 12)
            ' ---- Draw table header ----
            g.DrawString("CLASS", headerFont, Brushes.Black, startX, startY)
            g.DrawString("TOTAL", headerFont, Brushes.Black, startX + 120, startY)
            g.DrawString("SCHEME", headerFont, Brushes.Black, startX + 220, startY)
            g.DrawString("DISCOUNT", headerFont, Brushes.Black, startX + 320, startY)
            g.DrawString("CGST", headerFont, Brushes.Black, startX + 440, startY)
            g.DrawString("SGST", headerFont, Brushes.Black, startX + 540, startY)
            g.DrawString("SUB TOTAL", headerFont, Brushes.Black, startX + 620, startY)
            g.DrawString(sbtotal, normalFont, Brushes.Black, startX + 750, startY - 1)

            Dim rowY As Integer = startY + 25
            Dim grandTotal As Decimal = 0
            Dim grandCgst As Decimal = 0
            Dim grandSgst As Decimal = 0

            For Each rateRow In gstSummary
                Dim rate As Decimal = rateRow("rate")
                Dim total As Decimal = rateRow("total")
                Dim cgstAmount As Decimal = rateRow("cgstAmount")
                Dim sgstAmount As Decimal = rateRow("sgstAmount")
                grandTotal += total
                grandCgst += cgstAmount
                grandSgst += sgstAmount
                g.DrawString("GST " & rate.ToString("0.00") & "%", normalFont, Brushes.Black, startX, rowY)
                g.DrawString(total.ToString("0.00"), normalFont, Brushes.Black, startX + 120, rowY)
                g.DrawString("0.00", normalFont, Brushes.Black, startX + 220, rowY)
                g.DrawString(discount.ToString("0.00"), normalFont, Brushes.Black, startX + 320, rowY)
                g.DrawString(cgstAmount.ToString("0.00"), normalFont, Brushes.Black, startX + 440, rowY)
                g.DrawString(sgstAmount.ToString("0.00"), normalFont, Brushes.Black, startX + 540, rowY)
                g.DrawString(If(discount > 0, "GST", "CGST"), headerFont, Brushes.Black, If(discount > 0, startX + 673, startX + 664), rowY)
                g.DrawString(If(discount > 0, cgstAmount + sgstAmount, cgstAmount.ToString("0.00")), normalFont, Brushes.Black, startX + 750, rowY)
                rowY += 22
              
            Next
            grndtotal -= discount
            ' ---- TOTAL ROW ----
            g.DrawString("TOTAL", headerFont, Brushes.Black, startX, rowY)
            g.DrawString(grandTotal.ToString("0.00"), headerFont, Brushes.Black, startX + 120, rowY)
            g.DrawString("0.00", headerFont, Brushes.Black, startX + 220, rowY)
            g.DrawString(discount.ToString("0.00"), headerFont, Brushes.Black, startX + 320, rowY)
            g.DrawString(grandCgst.ToString("0.00"), headerFont, Brushes.Black, startX + 440, rowY)
            g.DrawString(grandSgst.ToString("0.00"), headerFont, Brushes.Black, startX + 540, rowY)
            g.DrawString(If(discount > 0, "DISCOUNT", "SGST"), headerFont, Brushes.Black, If(discount > 0, startX + 628, startX + 664), rowY + 2)
            g.DrawString(If(discount > 0, discount.ToString("0.00"), grandSgst.ToString("0.00")), normalFont, Brushes.Black, startX + 750, rowY + 2)
            g.DrawString("GRAND TOTAL", headerFont, Brushes.Black, startX + 591, rowY + 28)
            g.DrawString(grndtotal, headerFont, Brushes.Black, startX + 750, rowY + 28)
            Dim actualGridHeight As Integer = grid.Rows.GetRowsHeight(DataGridViewElementStates.Visible) _
    + grid.ColumnHeadersHeight + 20
            ' -----TOTAL AMOUNT---------

            ' ---- DRAW VERTICAL GRID LINES ----
            Dim lineY1 As Integer = startY - 9          ' top line
            Dim lineY2 As Integer = rowY + 27           ' bottom line (after total row)
            Using p As New Pen(Color.Black, 1.5)
                p.DashStyle = Drawing2D.DashStyle.Solid
                g.SmoothingMode = Drawing2D.SmoothingMode.None
                ' Left border
                g.DrawLine(p, startX - 9, lineY1, startX - 9, lineY2 + 24)
                ' over cgst
                g.DrawLine(p, startX + 610, rowY - 23, startX + 840, rowY - 23)
                g.DrawLine(p, startX + 610, rowY + 2, startX + 840, rowY + 2)

                ' After CLASS
                g.DrawLine(p, startX + 95, lineY1, startX + 95, lineY2)

                ' After TOTAL
                g.DrawLine(p, startX + 205, lineY1, startX + 205, lineY2)

                ' After SCHEME
                g.DrawLine(p, startX + 305, lineY1, startX + 305, lineY2)

                ' After DISCOUNT
                g.DrawLine(p, startX + 415, lineY1, startX + 415, lineY2)

                ' After CGST
                g.DrawLine(p, startX + 515, lineY1, startX + 515, lineY2)

                ' Right border
                g.DrawLine(p, startX + 610, lineY1, startX + 610, lineY2)
                ' bottom line 1,2
                g.DrawLine(p, startX - 9, rowY + 27, startX + 840, rowY + 27)
                g.DrawLine(p, startX - 9, rowY + 52, startX + 840, rowY + 52)
                ' left of Amount section
                g.DrawLine(p, startX + 720, lineY1, startX + 720, lineY2 + 24)
                'right of amount section
                g.DrawLine(p, startX + 840, lineY1, startX + 840, lineY2 + 24)
            End Using
            '
            Dim amountInWords As String = NumberToWords(grndtotal)
            g.DrawString(amountInWords, headerFont, Brushes.Black, startX, rowY + 28)
            '---- 7. Save Image ----
            Dim filePath As String = "Bill_" & Now.ToString("ddMMyyyy_HHmmss") & ".png"
            billImg.Save(filePath, Imaging.ImageFormat.Png)

            MessageBox.Show("Bill saved as: " & filePath)
            '---- RESTORE GRID BORDERS ----
            grid.CellBorderStyle = oldCellBorder
            grid.GridColor = oldGridColor
            grid.Refresh()

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try

    End Sub


    Private Sub grid_CellEndEdit(ByVal sender As Object, ByVal e As DataGridViewCellEventArgs)
        If grid.Columns(e.ColumnIndex).Name = "Amount" Then
            CalculateTotal()
            Exit Sub
        End If
        If grid.Columns(e.ColumnIndex).Name = "cgst" Then
            Dim cgstValue As Decimal = 0

            If Decimal.TryParse(grid.Rows(e.RowIndex).Cells("cgst").Value, cgstValue) Then
                ' SGST is always same as CGST
                grid.Rows(e.RowIndex).Cells("sgst").Value = cgstValue
            End If
        End If
        Try
            Dim row = grid.Rows(e.RowIndex)

            Dim qty As Decimal = Val(row.Cells("Qty").Value)
            Dim rate As Decimal = Val(row.Cells("Rate").Value)
            Dim cgstPercent As Decimal = Val(row.Cells("CGST").Value)
            Dim sgstPercent As Decimal = Val(row.Cells("SGST").Value)
            If qty > 0 And rate > 0 Then
                Dim baseAmount As Decimal = qty * rate
                Dim gstAmount As Decimal = (baseAmount * (cgstPercent + sgstPercent)) / 100
                Dim totalAmount As Decimal = baseAmount + gstAmount

                row.Cells("Amount").Value = totalAmount.ToString("0.00")
            End If

            CalculateTotal()

        Catch
            ' ignore invalid input
        End Try
    End Sub

    Private Sub ClearAll(ByVal sender As Object, ByVal e As EventArgs)
        grid.Rows.Clear()
        lblSubtotal.Text = "Subtotal: 0"
        lblGST.Text = "GST (18%): 0"
        lblTotal.Text = "Total: 0"
    End Sub


    '======================== CONTROLS ===========================
    Private txtItem As TextBox
    Private txtQty As TextBox
    Private txtPrice As TextBox
    Private grid As DataGridView
    Private lblSubtotal As Label
    Private lblGST As Label
    Private lblTotal As Label
    Private Function CalculateGstSummary() As List(Of Dictionary(Of String, Decimal))
        Dim summary As New Dictionary(Of Decimal, Dictionary(Of String, Decimal))

        For Each row As DataGridViewRow In grid.Rows
            If row.IsNewRow Then Continue For

            Dim amount As Decimal = Val(row.Cells("Amount").Value)
            Dim cgst As Decimal = Val(row.Cells("CGST").Value)
            Dim sgst As Decimal = Val(row.Cells("SGST").Value)

            Dim totalGst As Decimal = cgst + sgst

            If Not summary.ContainsKey(totalGst) Then
                summary(totalGst) = New Dictionary(Of String, Decimal) From {
                    {"total", 0},
                    {"cgstAmount", 0},
                    {"sgstAmount", 0}
                }
            End If

            Dim baseAmount As Decimal = Val(row.Cells("Qty").Value) * Val(row.Cells("Rate").Value)
            summary(totalGst)("total") += baseAmount
            summary(totalGst)("cgstAmount") += (baseAmount * cgst / 100)
            summary(totalGst)("sgstAmount") += (baseAmount * sgst / 100)
        Next

        ' Convert for use in display
        Dim result As New List(Of Dictionary(Of String, Decimal))
        For Each gst In summary.Keys
            result.Add(New Dictionary(Of String, Decimal) From {
                {"rate", gst},
                {"total", summary(gst)("total")},
                {"cgstAmount", summary(gst)("cgstAmount")},
                {"sgstAmount", summary(gst)("sgstAmount")}
            })
        Next

        Return result
    End Function
    Private Function NumberToWords(ByVal number As Decimal) As String
        Dim rupees As Long = Math.Floor(number)
        Dim paise As Integer = CInt(Math.Round((number - rupees) * 100))

        Dim result As String = "Rupees " & ConvertToWords(rupees)

        If paise > 0 Then
            result &= " and Paise " & ConvertToWords(paise)
        End If

        result &= " Only"
        Return result
    End Function

    Private Function ConvertToWords(ByVal num As Long) As String
        If num = 0 Then Return "Zero"

        Dim units() As String = {
            "", "One", "Two", "Three", "Four", "Five", "Six",
            "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve",
            "Thirteen", "Fourteen", "Fifteen", "Sixteen",
            "Seventeen", "Eighteen", "Nineteen"
        }

        Dim tens() As String = {
            "", "", "Twenty", "Thirty", "Forty",
            "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"
        }

        Dim words As String = ""

        If num \ 10000000 > 0 Then
            words &= ConvertToWords(num \ 10000000) & " Crore "
            num = num Mod 10000000
        End If

        If num \ 100000 > 0 Then
            words &= ConvertToWords(num \ 100000) & " Lakh "
            num = num Mod 100000
        End If

        If num \ 1000 > 0 Then
            words &= ConvertToWords(num \ 1000) & " Thousand "
            num = num Mod 1000
        End If

        If num \ 100 > 0 Then
            words &= ConvertToWords(num \ 100) & " Hundred "
            num = num Mod 100
        End If

        If num > 0 Then
            If num < 20 Then
                words &= units(num)
            Else
                words &= tens(num \ 10)
                If num Mod 10 > 0 Then
                    words &= " " & units(num Mod 10)
                End If
            End If
        End If

        Return words.Trim()
    End Function
    Private Sub BillingForm_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs) Handles Me.KeyDown
        If e.Control AndAlso e.KeyCode = Keys.D Then
            e.SuppressKeyPress = True   ' prevent default behavior

            Dim input As String = InputBox("Enter Discount:", "Input Required")

            If input <> "" Then
                discount = input
                ' You can assign it anywhere, example:
                ' txtto.Text = input
            End If
        End If
    End Sub

End Class

